public class Main {
    public static void main(String[] args) {
        int Denis =101;
        int Anna = 50;
        int summaplus = Denis + Anna;
        System.out.println( summaplus);
        int summaminus = Denis - Anna;
        System.out.println(summaminus);
        int summaum = Denis * Anna;
        System.out.println(summaum);
        int summadel = Denis / Anna;
        System.out.println(summadel);
        int delsostatkom =Denis % Anna;
        System.out.println(delsostatkom);

    }
}