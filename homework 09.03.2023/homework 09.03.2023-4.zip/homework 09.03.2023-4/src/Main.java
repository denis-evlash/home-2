public class Main {
    public static void main(String[] args) {
        int i1 = 123456;
        int i2 = 234567;
        long l1 = 3456789;
        long l2 = 567891234;
        double d1 = 1.23;
        double d2 = 5.58;
        float f1 = 32.45f;
        float f2 = 88.88f;
        int  vywod = i1 + i2;
        long vywod1 = l1 + l2;
        long vywod2 = i1 + l1;
        float vywod3 = i1 + f1;
        double vywod4 = i1 + d1;
        double vywod5 = l1 + d1;
        System.out.println(vywod);
        System.out.println(vywod1);
        System.out.println(vywod2);
        System.out.println(vywod3);
        System.out.println(vywod4);
        System.out.println(vywod5);

        ;
    }
}