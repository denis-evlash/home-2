public class Main {
    public static void main(String[] args) {
        byte Denis = 127;
        System.out.println(Denis);
        int Denis1 = Denis + 1;
        System.out.println(Denis1);
        System.out.println();


        //* вариант слизаный с  продленки *//
        byte Denis3 = 127;
        System.out.println(Denis3);
        Denis3++;
        System.out.println(Denis3);


    }
}