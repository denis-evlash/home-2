public class Main {
    public static void main(String[] args) {
        boolean Denis0 = true;
        byte Denis = 10;
        short Denis1 = 1000;
        int Denis2 = 10000;
        long Denis3 = 1000000;
        float Denis4 = 1.24f;
        double Denis5 = 1.23;
        char Denis6 = 'b';
        System.out.println(Denis1);
        System.out.println(Denis2);
        System.out.println(Denis3);
        System.out.println(Denis4);
        System.out.println(Denis5);
        System.out.println(Denis6);
        Denis2 = Denis2 -1;
        System.out.println(Denis2);
        Denis3 = Denis3 +500;
        System.out.println(Denis3);
        Denis4 = Denis4 +500;
        System.out.println(Denis4);


    }
}