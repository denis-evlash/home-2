public class Main {
    public static void main(String[] args) {
        System.out.println(5 % 4);
        System.out.println(15 % 3);
        System.out.println();

        System.out.println(2 % 2);
        System.out.println(7 % 2);
        System.out.println(13 % 2);
        System.out.println(14 % 2);
        System.out.println();

        boolean x1 = 2 % 2 == 0;
        System.out.println(" true  четное falce не четное: " + x1);
        boolean x2 = 7 % 2 == 0;
        System.out.println(" true  четное falce не четное: " + x2);
        boolean x3 = 13 % 2 == 0;
        System.out.println(" true  четное falce не четное: " + x3);
        boolean x4 = 14 % 2 == 0;
        System.out.println(" true  четное falce не четное: " + x4);
        System.out.println();
        int  eee = 58 % 10;
        System.out.println(eee);

    }
}